# Магазин одежды (Node.js)

## Запуск
1. Установи Node.js 18+ (nodejs.org)
2. В папке проекта: `npm install`
3. Запуск (Windows PowerShell): `$env:ADMIN_PASSWORD="твой_пароль"; npm start`
   Linux/Mac: `ADMIN_PASSWORD=твой_пароль npm start`
4. Сайт: http://localhost:3000 — админка: http://localhost:3000/admin.html

Все изменения из админки сразу видны на сайте у всех посетителей (Server-Sent Events).
Данные лежат в папке `data/` (db.json и фото) — делай её резервные копии.

## Выложить в интернет
Подойдёт Render, Railway, Fly.io или обычный VPS. Нужно задать переменную `ADMIN_PASSWORD`
и подключить постоянный диск к папке `data` (переменная `DATA_DIR`), иначе товары пропадут при перезапуске.

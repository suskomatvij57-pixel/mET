const express=require('express'),multer=require('multer'),fs=require('fs'),path=require('path'),crypto=require('crypto');
const PORT=process.env.PORT||3000, PASS=process.env.ADMIN_PASSWORD||'admin123';
const DATA=process.env.DATA_DIR||path.join(__dirname,'data'), UP=path.join(DATA,'uploads'), DBF=path.join(DATA,'db.json');
fs.mkdirSync(UP,{recursive:true});
let db={settings:{name:'МАГАЗИН',title:'Одежда, в которой удобно жить',sub:'Новая коллекция уже в наличии',contact:''},products:[]};
if(fs.existsSync(DBF)) db=JSON.parse(fs.readFileSync(DBF,'utf8'));
const tokens=new Set(), clients=new Set();
function commit(){fs.writeFileSync(DBF+'.tmp',JSON.stringify(db));fs.renameSync(DBF+'.tmp',DBF);
  const m=`data: ${JSON.stringify(db)}\n\n`;clients.forEach(c=>c.write(m));}
const auth=(req,res,next)=>tokens.has((req.headers.authorization||'').replace('Bearer ',''))?next():res.sendStatus(401);
const upload=multer({storage:multer.diskStorage({destination:UP,
  filename:(r,f,cb)=>cb(null,crypto.randomUUID()+path.extname(f.originalname).toLowerCase().replace(/[^.a-z0-9]/g,''))}),
  limits:{fileSize:5e6},fileFilter:(r,f,cb)=>cb(null,/^image\//.test(f.mimetype))});
const app=express();app.use(express.json());
let fails=0;setInterval(()=>fails=0,60000);
app.post('/api/login',(req,res)=>{
  if(fails>=10)return res.sendStatus(429);
  if(req.body.password!==PASS){fails++;return res.sendStatus(401)}
  const t=crypto.randomUUID();tokens.add(t);res.json({token:t});});
app.get('/api/data',(q,r)=>r.json(db));
app.get('/api/stream',(req,res)=>{
  res.set({'Content-Type':'text/event-stream','Cache-Control':'no-cache',Connection:'keep-alive'});res.flushHeaders();
  res.write(`data: ${JSON.stringify(db)}\n\n`);clients.add(res);req.on('close',()=>clients.delete(res));});
const fields=(b,f,old={})=>({...old,name:String(b.name||'').slice(0,120),price:Number(b.price)||0,cat:String(b.cat||'').slice(0,60),
  sizes:String(b.sizes||'').slice(0,80),img:f?'/uploads/'+f.filename:(b.img||old.img||'')});
app.post('/api/products',auth,upload.single('image'),(req,res)=>{
  const p={id:crypto.randomUUID(),ts:Date.now(),...fields(req.body,req.file)};db.products.push(p);commit();res.json(p);});
app.put('/api/products/:id',auth,upload.single('image'),(req,res)=>{
  const i=db.products.findIndex(p=>p.id===req.params.id);if(i<0)return res.sendStatus(404);
  db.products[i]=fields(req.body,req.file,db.products[i]);commit();res.json(db.products[i]);});
app.delete('/api/products/:id',auth,(req,res)=>{db.products=db.products.filter(p=>p.id!==req.params.id);commit();res.sendStatus(204);});
app.put('/api/settings',auth,(req,res)=>{
  for(const k of ['name','title','sub','contact'])if(typeof req.body[k]==='string')db.settings[k]=req.body[k].slice(0,300);
  commit();res.json(db.settings);});
app.use('/uploads',express.static(UP));app.use(express.static(path.join(__dirname,'public')));
app.listen(PORT,()=>console.log('Магазин: http://localhost:'+PORT+'  Админка: /admin.html'));
